#include "CApplication.hpp"
using namespace std;

int main()
{
    CApplication app;
    app.Run();

    return 0;
}
